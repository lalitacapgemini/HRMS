package com.cg.training.services;

import java.time.LocalDate;
import java.util.List;
import com.cg.training.entities.Salaries;
import com.cg.training.exceptions.SalariesNotFoundException;

public interface SalariesService {

	List<Salaries> getSalary();

	List<Salaries> getSalaryByFromDate(LocalDate fromDate)throws SalariesNotFoundException;

	List<Salaries> getSalariesByEmployee(int empNo)throws SalariesNotFoundException;

	List<Salaries> getSalaryByRange(int minSalary, int maxSalary)throws SalariesNotFoundException;

	

	Salaries addSalary(Salaries salary);

	Salaries updateSalary(Salaries salary)throws SalariesNotFoundException;

	Salaries getSalaryByFromDates(LocalDate fromDate)throws SalariesNotFoundException;

	Salaries getSalariesByEmployees(int empNo)throws SalariesNotFoundException;

	void deleteByEmpNoAndFromDate(int empNo, LocalDate fromDate)throws SalariesNotFoundException;

	void deleteByFromDate(LocalDate fromDate)throws SalariesNotFoundException;

	void deleteByEmpNo(int empNo)throws SalariesNotFoundException;

}