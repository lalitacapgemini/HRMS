package com.cg.training.exceptions;

public class DepartmentEmployeeNotFoundException extends Exception {


	String message;

	public DepartmentEmployeeNotFoundException(String message) {
		super();
		this.message = message;
	}
	
	public String getMessage() {
		return this.message;
	}
}
