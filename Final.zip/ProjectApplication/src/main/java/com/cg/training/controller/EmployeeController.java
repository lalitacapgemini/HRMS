package com.cg.training.controller;

import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.training.entities.Employee;
import com.cg.training.entities.Gender;
import com.cg.training.exceptions.EmployeeNotFoundException;
import com.cg.training.exceptions.InvalidDataException;
import com.cg.training.exceptions.NotFoundException;
import com.cg.training.services.EmployeeServiceImpl;

import io.swagger.v3.oas.annotations.Operation;

//It contains various endpoints for managing employee data.
@RestController
@RequestMapping("/api/v1/employees")
public class EmployeeController {

	@Autowired
	public EmployeeServiceImpl employeeService;
	

	@GetMapping("/all")
	@Operation(summary = "Fetch all employees.")
	public List<Employee> findAllEmployees() {
		
		return employeeService.getEmployee();
	}

	
	@GetMapping("/{id}")
	@Operation(summary = "Fetch an employees by employee number")
	public Employee findEmployeeById(@PathVariable int id) throws EmployeeNotFoundException { // Change
		
		if (employeeService.getEmployeeById(id) != null)
			return employeeService.getEmployeeById(id);
		else
			throw new NotFoundException("Employee Id is not correct! Please check again");
	}

	
	@GetMapping("/firstname/{firstName}")
	@Operation(summary = "Search Employee by First Name")
	public List<Employee> findEmployeeByFirstName(@PathVariable("firstName") String firstName) throws EmployeeNotFoundException {
	
		if (employeeService.getEmployeeByFirstName(firstName) != null)
			return employeeService.getEmployeeByFirstName(firstName);
		else
			throw new NotFoundException("First Name is not correct! Please Check again.");
	}

	@GetMapping("/lastname/{lastName}")
	@Operation(summary = "Search Employee by Last Name")
	public List<Employee> findEmployeeByLastName(@PathVariable("lastName") String lastName) throws EmployeeNotFoundException {
		
		return employeeService.getEmployeeByLastName(lastName);
	}

	
	@GetMapping("/gender/{gender}")
	@Operation(summary = "Search employees by gender")
	public List<Employee> findByGender(@PathVariable("gender") String gender) {
		
		Gender g = Gender.valueOf(gender);
		return employeeService.getEmployeesByGender(g);
	}

	
	@GetMapping("/hiredate/{hiredate}")
	@Operation(summary = "Search employees by  hire date")
	public List<Employee> findEmployeesByHireDate(
			@PathVariable("hiredate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate hireDate) throws EmployeeNotFoundException {
		
		return employeeService.getEmployeesByHireDate(hireDate);
	}

	
	@GetMapping("/birthdate/{birthdate}")
	@Operation(summary = "Search employees by  birth date")
	public List<Employee> findEmployeesByBirthDate(
			@PathVariable("birthdate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate birthDate) throws EmployeeNotFoundException {
		
		return employeeService.getEmployeesByBirthDate(birthDate);
	}
	
	
	@PostMapping("/add")
	@Operation(summary = "Add new employee object in DB")
	public ResponseEntity<String> addEmployeeC(@RequestBody Employee employee) throws EmployeeNotFoundException {
	
		Employee response = employeeService.addEmployee(employee);
		if (response != null)
			return new ResponseEntity<String>("New employee added successfully", HttpStatus.OK);
		else
			throw new InvalidDataException("Validation Failed: Invalid entry.Please Check again");
	}

	
	@PutMapping("/lastname/{empno}")
	@Operation(summary = "Update Last Name of an employee given empno")
	public ResponseEntity<Employee> updateEmployeeByLastNameC(@PathVariable("empno") int empNo,
			@RequestBody Employee employee) throws EmployeeNotFoundException {
		
		Employee emp = employeeService.updateEmployeeLastName(employee, empNo);

		if (emp != null)
			return new ResponseEntity<Employee>(emp, HttpStatus.OK);
		else
			throw new NotFoundException("Invalid Id: Unable to update the lastname");
	}

	
	@PutMapping("/firstname/{empno}")
	@Operation(summary = "Update first Name of an employee given empno")
	public ResponseEntity<Employee> updateEmployeeByFirstNameC(@PathVariable("empno") int empNo,
			@RequestBody Employee employee) throws EmployeeNotFoundException {
		
		Employee emp = employeeService.updateEmployeeFirstName(employee, empNo);
		if (emp != null)
			return new ResponseEntity<Employee>(emp, HttpStatus.OK);
		else
			throw new NotFoundException("Invalid Id: Unable to update the firstname");
	}

	
	@PutMapping("/hiredate/{empno}")
	@Operation(summary = "Update hiredate for given empno")
	public Employee updateEmployeeByHireDateC(@PathVariable("empno") int empNo, @RequestBody Employee employee) throws EmployeeNotFoundException {
		
		return employeeService.updateEmployeeByHireDate(employee, empNo);
	}

	@PutMapping("/birthdate/{empno}")
	@Operation(summary = "Update birthdate for given empno")
	public Employee updateEmployeeByBirthDateC(@PathVariable("empno") int empNo, @RequestBody Employee employee) throws EmployeeNotFoundException {
		
		return employeeService.updateEmployeeBirthDate(employee, empNo);
	}

}