package com.cg.training.services;

import java.time.LocalDate;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.training.dao.SalariesRepository;
import com.cg.training.entities.Salaries;
import com.cg.training.exceptions.SalariesNotFoundException;


@Service
public class SalariesServiceImpl implements SalariesService {

 

    @Autowired
    private SalariesRepository salaryRepository;
    public List<Salaries> getSalary() {
        return salaryRepository.findAll();
    }

    @Override
    public List<Salaries> getSalaryByFromDate(LocalDate fromDate) throws SalariesNotFoundException {
        List<Salaries> salaries = salaryRepository.findAllByFromDate(fromDate);

        if (salaries.isEmpty()) {
            throw new SalariesNotFoundException("No salaries found for fromDate: " + fromDate);
        }

        return salaries;
    }


    @Override
    public List<Salaries> getSalariesByEmployee(int empNo) throws SalariesNotFoundException {
        List<Salaries> salaries = salaryRepository.findSalaryByEmployee(empNo);

        if (salaries.isEmpty()) {
            throw new SalariesNotFoundException("No salaries found for employee with empNo: " + empNo);
        }

        return salaries;
    }



    
    @Override
    public List<Salaries> getSalaryByRange(int minSalary, int maxSalary) throws SalariesNotFoundException {
        List<Salaries> salaries = salaryRepository.findAllBySalaryBetween(minSalary, maxSalary);

        if (salaries.isEmpty()) {
            throw new SalariesNotFoundException("No salaries found in the range: " + minSalary + " to " + maxSalary);
        }

        return salaries;
    }

    public Salaries getSalaryByEmpNoAndFromDate(int empNo, LocalDate fromDate) throws SalariesNotFoundException {
        Salaries salary = salaryRepository.findbyempnoandfromdate(empNo, fromDate);

        if (salary == null) {
            throw new SalariesNotFoundException("Salary not found for empNo: " + empNo + " and fromDate: " + fromDate);
        }

        return salary;
    }


   
    public Salaries addSalary(Salaries salary) {
         return salaryRepository.save(salary);

    }
    
    
    public Salaries updateSalary(Salaries salary) throws SalariesNotFoundException {
        Salaries s = salaryRepository.save(salary);
        if(s==null) {
        	throw new SalariesNotFoundException("salaries not found for the given criteria");
        }
        return s;
        
    }


    
    public Salaries getSalaryByFromDates(LocalDate fromDate) throws SalariesNotFoundException {
        Salaries salary = salaryRepository.findbyfromdate(fromDate);
        if(salary==null) {
        	throw new SalariesNotFoundException("salary not found for"+fromDate);
        }
        return salary;
    }

 
    @Override
    public Salaries getSalariesByEmployees(int empNo) throws SalariesNotFoundException {
        // Retrieve the list of salaries for the given empNo
        List<Salaries> salaries = salaryRepository.findSalaryByEmployee(empNo);

        if (salaries.isEmpty()) {
            throw new SalariesNotFoundException("No salaries found for empNo: " + empNo);
        }

        // For simplicity, if there are multiple salaries for the same employee, return the first one
        return salaries.get(0);
    }

    @Transactional
    @Override
    public void deleteByEmpNoAndFromDate(int empNo, LocalDate fromDate) throws SalariesNotFoundException {
        // Delete salaries with the given empNo and fromDate
        String deletedCount = salaryRepository.deleteByEmployeeEmpNoAndFromDate(empNo, fromDate);

        if (deletedCount == null) {
            throw new SalariesNotFoundException("No salaries found for empNo: " + empNo + " and fromDate: " + fromDate);
        }
    }


    @Transactional
    public void deleteByFromDate(LocalDate fromDate) throws SalariesNotFoundException {
        String deletedCount = salaryRepository.deleteByFromDate(fromDate);
        
        if (deletedCount == null) {
            // If no salaries were deleted, throw the custom exception
            throw new SalariesNotFoundException("No salaries found for fromDate: " + fromDate);
        }
    }

    
    
    @Transactional
    public void deleteByEmpNo(int empNo) throws SalariesNotFoundException {
        String deletedCount = salaryRepository.deleteByEmployeeEmpNo(empNo);
        
        if (deletedCount == null) {
            // If no salaries were deleted, throw the custom exception
            throw new SalariesNotFoundException("No salaries found for empNo: " + empNo);
        }
    }

	public Salaries getSalaryByEmpNoandFromDate(int empNo, LocalDate fromDate) {
		// TODO Auto-generated method stub
		return null;
	}

	

    
}
