package com.cg.training.services;

import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.training.dao.DepartmentEmployeeRepository;
import com.cg.training.entities.DepartmentEmployee;
import com.cg.training.exceptions.DepartmentEmployeeNotFoundException;



@Service
public class DepartmentEmployeeServiceImpl implements DepartmentEmployeeService {
	
	@Autowired
	private  DepartmentEmployeeRepository departmentEmployeeRepository;
	
	
	public List<DepartmentEmployee> getdepartmentemployee() {
		return 	departmentEmployeeRepository.findAll();
	}
	
	
	public List<DepartmentEmployee> findByDeptNoAndFromDate(String deptNo, LocalDate fromDate) throws DepartmentEmployeeNotFoundException {
	  
	    List<DepartmentEmployee> result = departmentEmployeeRepository.findByDepartmentDeptNoAndFromDate(deptNo, fromDate);

	    if (result.isEmpty()) {
	        // If the result is empty, throw a custom exception
	        throw new DepartmentEmployeeNotFoundException("No DepartmentEmployees found for deptNo: " + deptNo + " and fromDate: " + fromDate);
	    }

	    return result;
	}

	 
	
	public DepartmentEmployee findBysDeptNoAndFromDate(String deptNo, LocalDate fromDate) throws DepartmentEmployeeNotFoundException {
	    DepartmentEmployee departmentEmployee = departmentEmployeeRepository.findByDepartment_DeptNoAndFromDate(deptNo, fromDate);

	    if (departmentEmployee == null) {
	        // If the departmentEmployee is null, throw a custom exception
	        throw new DepartmentEmployeeNotFoundException("DepartmentEmployee not found for deptNo: " + deptNo + " and fromDate: " + fromDate);
	    }

	    return departmentEmployee;
	}

	    
	 
	public DepartmentEmployee findByempNoAndFromDate(int empNo, LocalDate fromDate) throws DepartmentEmployeeNotFoundException {
	    DepartmentEmployee departmentEmployee = departmentEmployeeRepository.findByEmployee_EmpNoAndFromDate(empNo, fromDate);

	    if (departmentEmployee == null) {
	        // If the departmentEmployee is null, throw a custom exception
	        throw new DepartmentEmployeeNotFoundException("DepartmentEmployee not found for empNo: " + empNo + " and fromDate: " + fromDate);
	    }

	    return departmentEmployee;
	}

	    
	   
	public DepartmentEmployee getDepartEmployeeByEmpNoAndDeptNo(int empNo, String deptNo) throws DepartmentEmployeeNotFoundException {
	    DepartmentEmployee departmentEmployee = departmentEmployeeRepository.findByEmployee_EmpNoAndDepartment_DeptNo(empNo, deptNo);

	    if (departmentEmployee == null) {
	        // If the departmentEmployee is null, throw a custom exception
	        throw new DepartmentEmployeeNotFoundException("DepartmentEmployee not found for empNo: " + empNo + " and deptNo: " + deptNo);
	    }

	    return departmentEmployee;
	}

	    
	  
	public DepartmentEmployee getDepartmentEmployeeByEmpNoAndDeptNoAndFromDate(int empNo, String deptNo, LocalDate fromDate) throws DepartmentEmployeeNotFoundException {
	    DepartmentEmployee departmentEmployee = departmentEmployeeRepository.findByEmployee_EmpNoAndDepartment_DeptNoAndFromDate(empNo, deptNo, fromDate);

	    if (departmentEmployee == null) {
	        // If the departmentEmployee is null, throw a custom exception
	        throw new DepartmentEmployeeNotFoundException("DepartmentEmployee not found for empNo: " + empNo + ", deptNo: " + deptNo + ", and fromDate: " + fromDate);
	    }

	    return departmentEmployee;
	}

	    
	  
	public DepartmentEmployee updateDepartmentEmployee(DepartmentEmployee departmentEmployee) throws DepartmentEmployeeNotFoundException {

	    // Check if departmentEmployee is null
	    if (departmentEmployee == null) {
	        // If departmentEmployee is null, throw a custom exception
	        throw new DepartmentEmployeeNotFoundException("DepartmentEmployee is null. Cannot perform update.");
	    }

	    // Perform the update or save operation
	    return departmentEmployeeRepository.save(departmentEmployee);
	}

	    
	   
	    public DepartmentEmployee saveDepartmentEmployee(DepartmentEmployee departmentEmployee) {
	        return departmentEmployeeRepository.save(departmentEmployee);
	    }
    
	  	    
	    @Transactional
	    public void deleteByEmpNoAndDeptNoAndFromDate(int empNo, LocalDate fromDate, String deptNo) throws DepartmentEmployeeNotFoundException {
	        String deletecount = departmentEmployeeRepository.deleteByEmpNoAndDeptNoAndFromDate(empNo, deptNo, fromDate); 
	    	if(deletecount==null) {
	    		 throw new DepartmentEmployeeNotFoundException("DepartmentEmployee is null. Cannot perform delete operation.");
	    	}
	    }

	    
	    @Transactional
	    public void deleteByEmpNoAndDeptNo(int empNo, String deptNo) throws DepartmentEmployeeNotFoundException {
	        String deletecount = departmentEmployeeRepository.deleteByEmpNoAndDeptNo(empNo, deptNo); 
	    	if(deletecount==null) {
	    		 throw new DepartmentEmployeeNotFoundException("DepartmentEmployee is null. Cannot perform delete operation.");
	    	}
	    	
	    }

	    
	    @Transactional
	    public void deleteByEmpNoAndFromDate(int empNo, LocalDate fromDate) throws DepartmentEmployeeNotFoundException {
	        String deletecount = departmentEmployeeRepository.deleteByEmpNoAndFromDate(empNo, fromDate);
	    	if(deletecount==null) {
	    		 throw new DepartmentEmployeeNotFoundException("DepartmentEmployee is null. Cannot perform delete operation.");
	    	}
	    	
	    }

	    
	    @Transactional
	    public void deleteByDeptNoAndFromDate(String deptNo, LocalDate fromDate) throws DepartmentEmployeeNotFoundException {
	        String deletecount = departmentEmployeeRepository.deleteByDeptNoAndFromDate(deptNo, fromDate);
	    	if(deletecount==null) {
	    		 throw new DepartmentEmployeeNotFoundException("DepartmentEmployee is null. Cannot perform delete operation.");
	    	}
	    	
	    }	 
}
