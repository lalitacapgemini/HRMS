package com.cg.training.entities;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;


public class TitlesId implements Serializable{
	
    private LocalDate fromDate;
    private Employee employee;
    private String title;
	public TitlesId() {
		super();
		// TODO Auto-generated constructor stub
	}
	public TitlesId(LocalDate fromDate, Employee employee, String title) {
		super();
		this.fromDate = fromDate;
		this.employee = employee;
		this.title = title;
	}
	public LocalDate getFromDate() {
		return fromDate;
	}
	public void setFromDate(LocalDate fromDate) {
		this.fromDate = fromDate;
	}
	public Employee getEmployee() {
		return employee;
	}
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
   
	
	
}
