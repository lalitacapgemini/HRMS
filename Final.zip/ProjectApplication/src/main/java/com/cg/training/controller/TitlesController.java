package com.cg.training.controller;

import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.training.entities.Titles;
import com.cg.training.exceptions.InvalidDataException;
import com.cg.training.exceptions.TitlesNotFoundException;
import com.cg.training.services.TitleServiceImpl;

import io.swagger.v3.oas.annotations.Operation;
//It contains various endpoints for managing employee titles.
@RestController  // Restful controller
@RequestMapping("/api/v1/titles") // base url for apis related to titles
public class TitlesController {
	
	@Autowired // instead of creation of objects using new keyword
    private TitleServiceImpl titleService;
	
	
	/*
	 * Fetch all title objects.
	 */
    @GetMapping("/all") 
    @Operation(summary = "Fetch all titles objects")
    public List<Titles> findAllSalary() {
    	
       
        return titleService.getTitles();
    }

    //Add a new title object to the database.
    
    @PostMapping("/add")
    @Operation(summary = "Add new titles object in DB")
    public ResponseEntity<Titles> addNewTitles(@RequestBody Titles titles) {
    	
        Titles createdTitle = titleService.addTitle(titles);
        if (createdTitle != null) {
            return ResponseEntity.status(HttpStatus.OK).body(createdTitle);
        } else {
            throw new InvalidDataException("Validation Failed");
        }
    }
    
    
     //Fetch titles by employee number, from date, and title.
     
    @GetMapping("/empno/{empno}/fromdate/{fromdate}/title/{title}")
    @Operation(summary = "Search titles by from date, empno, title")
    public List<Titles> findByEmpNoAndFromDateAndTitle(@PathVariable("empno") int empNo,
            @PathVariable("fromdate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate,
            @PathVariable("title") String title) throws TitlesNotFoundException {
    	
        return titleService.getTitleByEmpNoAndDeptNo(empNo, fromDate, title);
    }

    
     //Fetch titles by title. 
     

    @GetMapping("/title/{title}")
    @Operation(summary = "Fetch all titles objects by title")
    public List<Titles> findAllByTitle(@PathVariable("title") String title) throws TitlesNotFoundException {
    
        return titleService.getAllByTitle(title);
    }

    
       //Fetch titles by from date.
     
    @GetMapping("/fromdate/{fromDate}")
    @Operation(summary = "Fetch all titles objects by from date")
    public List<Titles> findByFromDate(
            @PathVariable("fromDate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDateParam) throws TitlesNotFoundException {
    	
        return titleService.findAllByFromDate(fromDateParam);
    }

    
      //Fetch titles by title and from date.
	 
    @GetMapping("title/{title}/fromdate/{fromdate}")
    @Operation(summary = "Fetch all titles objects by title and fromdate")
    public List<Titles> findByEmpNoAndFromDateAndTitle(
            @PathVariable("fromdate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate,
            @PathVariable("title") String title) throws TitlesNotFoundException {
    	
        return titleService.getTitleByTitleAndFromDate(fromDate, title);
    }

 
    //Fetch titles by employee number and title.
     
    @GetMapping("/empno/{empno}/title/{title}")
    @Operation(summary = "Fetch all titles objects by empno and fromdate")
    public List<Titles> findByEmpNoAndAndTitle(@PathVariable("empno") int empNo, @PathVariable("title") String title) throws TitlesNotFoundException {
    	
    	return titleService.getTitleByTitleAndFromDate(empNo, title);
    }

    //Fetch titles by employee number and from date. 
     
    @GetMapping("/empno/{empno}/fromdate/{fromdate}")
    @Operation(summary = "Fetch all titles objects by empno and title")
    public List<Titles> findByEmpNoAndFromDate(@PathVariable("empno") int empNo,
            @PathVariable("fromdate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate) {
    
        return titleService.getTitleByEmpNoAndFromDate(empNo, fromDate);
    }
    
     //Update title by employee number, from date, and title.
     
    
	@PutMapping("/empno/{empNo}/fromdate/{fromDate}/title/{title}")
    public ResponseEntity<Void> updateTitle(
            @RequestBody Titles titl,
            @PathVariable int empNo,
            @PathVariable @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate,
            @PathVariable String title) throws TitlesNotFoundException {
        Titles existingTitle = titleService.findByEmpNoAndFromDateAndTitle(empNo, fromDate, title);
        if (existingTitle != null) {
        	existingTitle.setTitle(titl.getTitle());
            titleService.updateByEmpNo(existingTitle);
            return ResponseEntity.status(HttpStatus.OK).build();
        }
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }
	
	// Update title by employee number.
	 
	@PutMapping("/empno/{empNo}")
    public ResponseEntity<String> updateTitle(@RequestBody String titl,@PathVariable int empNo) throws TitlesNotFoundException {
		titleService.updateByEmpNo(empNo, titl);
        return new ResponseEntity<>("Details updated successfully",HttpStatus.OK);
    }
	
	 // Update title by from date.
	
	@PutMapping("/fromdate/{fromDate}")
    public ResponseEntity<String> updateTitle(
            @RequestBody Titles titl,
            @PathVariable @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate) throws TitlesNotFoundException {
		
        Titles existingTitle = titleService.findByFromDates(fromDate);
        if (existingTitle != null) {
        	existingTitle.setTitle(titl.getTitle());
        	existingTitle.setToDate(titl.getToDate());
            titleService.updateByEmpNo(existingTitle);
            return new ResponseEntity<>("Details updated successfully",HttpStatus.OK);
        }
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }
	
	//Update title by title.
	
	@PutMapping("/title/{title}")
    public ResponseEntity<String> updateTitle(
            @RequestBody Titles titl,
            @PathVariable String title) throws TitlesNotFoundException {
		
        Titles existingTitle = titleService.getbytitle(title);
        if (existingTitle != null) {
        	existingTitle.setTitle(titl.getTitle());
        	existingTitle.setToDate(titl.getToDate());
            titleService.updateByEmpNo(existingTitle);
            return new ResponseEntity<>("Details updated successfully",HttpStatus.OK);
        }
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }
  
	//Delete title by employee number, from date, and title.
	
	@DeleteMapping("/empno/{empNo}/fromdate/{fromDate}/title/{title}")
    public ResponseEntity<String> deleteTitleByEmpNoFromDateAndTitle(
    		@PathVariable int empNo,
            @PathVariable @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate,
            @PathVariable("title") String title) throws TitlesNotFoundException {
		
		titleService.deleteByEmpNoFromDateAndTitle(empNo, fromDate, title);
        return new ResponseEntity<>("Title deleted successfully",HttpStatus.OK);
    }
	
	  //Delete title by employee number.
	 
	@DeleteMapping("/empno/{empNo}")
    public ResponseEntity<String> deleteTitleByEmpNo(
    		@PathVariable int empNo) throws TitlesNotFoundException {

		titleService.deleteByEmpNo(empNo);
        return new ResponseEntity<>("Title deleted successfully",HttpStatus.OK);
    }
	
	 //Delete title by from date.
	 
	@DeleteMapping("/fromdate/{fromDate}")
    public ResponseEntity<String> deleteTitleByEmpNoFromDateAndTitle(
            @PathVariable @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate) throws TitlesNotFoundException {
		
		titleService.deleteByFromDate(fromDate);
        return new ResponseEntity<>("Title deleted successfully",HttpStatus.OK);
    }
	
	 //Delete title by title.
	
	@DeleteMapping("/title/{title}")
    public ResponseEntity<String> deleteByTitle(
            @PathVariable("title") String title) throws TitlesNotFoundException {
	
		titleService.deleteByTitle(title);
        return new ResponseEntity<>("Title deleted successfully",HttpStatus.OK);
    }
	
	
	
	
}
