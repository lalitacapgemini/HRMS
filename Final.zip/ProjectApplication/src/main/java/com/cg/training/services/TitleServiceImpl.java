package com.cg.training.services;

import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.training.dao.TitlesRepository;
import com.cg.training.entities.Titles;
import com.cg.training.exceptions.TitlesNotFoundException;


@Service
public class TitleServiceImpl implements TitleService {
	
	@Autowired
    private TitlesRepository titlesRepository;
	
    public List<Titles> getTitles() {
        return titlesRepository.findAll();
    }

  
    public Titles addTitle(Titles title) {
        return titlesRepository.save(title);
    }

  
    public List<Titles> getTitleByEmpNoAndDeptNo(int empNo, LocalDate fromDate, String title) throws TitlesNotFoundException {
       
        List<Titles> titles = titlesRepository.findByTypeId(empNo, fromDate, title);

        if (titles.isEmpty()) {
            // If no titles were found, throw the custom exception
            throw new TitlesNotFoundException("No titles found for empNo: " + empNo + ", fromDate: " + fromDate + ", and title: " + title);
        }

        return titles;
    }

 
    public List<Titles> getAllByTitle(String title) throws TitlesNotFoundException {
        List<Titles> titles = titlesRepository.findByTitles(title);

        if (titles.isEmpty()) {
            // If no titles were found, throw the custom exception
            throw new TitlesNotFoundException("No titles found with the title: " + title);
        }

        return titles;
    }

 
   
    public List<Titles> findAllByFromDate(LocalDate fromDate) throws TitlesNotFoundException {
        List<Titles> titles = titlesRepository.findByFromDate(fromDate);

        if (titles.isEmpty()) {
            // If no titles were found, throw the custom exception
            throw new TitlesNotFoundException("No titles found for the specified from date: " + fromDate);
        }

        return titles;
    }


 
   
    public List<Titles> getTitleByTitleAndFromDate(LocalDate fromDate, String title) throws TitlesNotFoundException {
        List<Titles> titles = titlesRepository.findByFromDateAndTitle(fromDate, title);

        if (titles.isEmpty()) {
            // If no titles were found, throw the custom exception
            throw new TitlesNotFoundException("No titles found for the specified title: " + title + " and from date: " + fromDate);
        }

        return titles;
    }


 
    
    public List<Titles> getTitleByTitleAndFromDate(int empNo, String title) throws TitlesNotFoundException {
        List<Titles> titles = titlesRepository.findByEmpnoAndTitle(empNo, title);

        if (titles.isEmpty()) {
            // If no titles were found, throw the custom exception
            throw new TitlesNotFoundException("No titles found for empNo: " + empNo + " and title: " + title);
        }

        return titles;
    }


    
    public List<Titles> getTitleByEmpNoAndFromDate(int empNo, LocalDate fromDate) {
        return titlesRepository.findByFromDateAnDempNo(empNo, fromDate);
    }

   
    public Titles findByEmpNoAndFromDateAndTitle(int empNo, LocalDate fromDate, String title) throws TitlesNotFoundException {
        Titles titles = titlesRepository.findByEmployee_EmpNoAndFromDateAndTitle(empNo, fromDate, title);

        if (titles == null) {
            // If no title was found, throw the custom exception
            throw new TitlesNotFoundException("No title found for empNo: " + empNo + ", fromDate: " + fromDate + ", and title: " + title);
        }

        return titles;
    }

	 
	
    public Titles getByEmpNo(int empNo) throws TitlesNotFoundException {
        
        Titles titles = titlesRepository.findByEmployee_EmpNo(empNo);
        
        if (titles == null) {
            // If no titles were found, throw the custom exception
            throw new TitlesNotFoundException("No titles found for empNo: " + empNo);
        }
        
        return titles;
    }

	
	
    public Titles findByFromDates(LocalDate fromDate) throws TitlesNotFoundException {
        Titles titles = titlesRepository.findByFromDate1(fromDate);
        
        if (titles == null) {
            // If no titles were found, throw the custom exception
            throw new TitlesNotFoundException("No titles found for fromDate: " + fromDate);
        }
        
        return titles;
    }

	
	
    public Titles getbytitle(String title) throws TitlesNotFoundException {
        Titles titles = titlesRepository.findByTitle(title);

        if (titles == null) {
            // If no titles were found, throw the custom exception
            throw new TitlesNotFoundException("No titles found for title: " + title);
        }

        return titles;
    }

	
	
    public void updateByEmpNo(int empNo, String title) throws TitlesNotFoundException {
        String updatedRows = titlesRepository.updateTitleByEmpNo(title, empNo);

        if (updatedRows == null) {
            // If no rows were updated, throw the custom exception
            throw new TitlesNotFoundException("No titles updated for empNo: " + empNo);
        }
    }


	
	@Transactional
	public void deleteByEmpNoFromDateAndTitle(int empNo, LocalDate fromDate, String title) throws TitlesNotFoundException {

	    String deletedRows = titlesRepository.deleteByEmployee_EmpNoAndFromDateAndTitle(empNo, fromDate, title);

	    if (deletedRows == null) {
	        // If no rows were deleted, throw the custom exception
	        throw new TitlesNotFoundException("No titles deleted for empNo: " + empNo + ", fromDate: " + fromDate + ", title: " + title);
	    }
	}

	@Transactional
	public void deleteByEmpNo(int empNo) throws TitlesNotFoundException {
	    String deletedRows = titlesRepository.deleteByEmployee_EmpNo(empNo);

	    if (deletedRows == null) {
	        // If no rows were deleted, throw the custom exception
	        throw new TitlesNotFoundException("No titles deleted for empNo: " + empNo);
	    }
	}

	
	
	@Transactional
	public void deleteByFromDate(LocalDate fromDate) throws TitlesNotFoundException {
	    String deletedRows = titlesRepository.deleteByFromDate(fromDate);

	    if (deletedRows == null) {
	        // If no rows were deleted, throw the custom exception
	        throw new TitlesNotFoundException("No titles deleted with fromDate: " + fromDate);
	    }
	}

	
	
	@Transactional
	 public void deleteByTitle(String title) throws TitlesNotFoundException {
        String deleteRows=titlesRepository.deletebyTitle(title);
        if(deleteRows==null) {
        	throw new TitlesNotFoundException("No record found to delete with title"+title);
        }
	        
	    }

	@Override
	public Titles updateByEmpNo(Titles titles) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
