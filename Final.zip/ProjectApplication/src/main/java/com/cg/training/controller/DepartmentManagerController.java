package com.cg.training.controller;

import java.time.LocalDate;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.training.entities.DepartmentManager;
import com.cg.training.entities.DepartmentManagerId;
import com.cg.training.exceptions.DepartmentManagerNotFoundException;
import com.cg.training.exceptions.InvalidDataException;
import com.cg.training.services.DepartmentManagerServiceImpl;

import io.swagger.v3.oas.annotations.Operation;


@RestController
@RequestMapping("/api/v1/departmentmanager")
public class DepartmentManagerController {

	@Autowired
	public DepartmentManagerServiceImpl departmentManagerService;

	//Retrieve a list of all department managers.
	@GetMapping("/all")
	@Operation(summary = "Fetch all deptmanager objects")
	public List<DepartmentManager> findAllDepartmentManager() {
		
		return departmentManagerService.getDepartmentManager();
	}

	
	  //Retrieve a department manager by employee number and department number.
	 
	@GetMapping("/empno/{empNo}/deptno/{deptNo}")
	@Operation(summary = "Search deptmanager by empno and deptno")
	public DepartmentManager findByEmpNoDeptNo(@PathVariable("empNo") int empNo,
			@PathVariable("deptNo") String deptNo) throws DepartmentManagerNotFoundException {
		
		return departmentManagerService.getDepartmentManagersByEmpNoAndDeptNo(empNo, deptNo);
	}

	//Retrieve a department manager by employee number and department number.
	@GetMapping("/deptno/{deptNo}/fromdate/{fromDate}")
	@Operation(summary = "Fetch all deptmanager objects by, deptno and from date")
	public List<DepartmentManager> findByDeptNoFromDate(@PathVariable("deptNo") String deptNo,
			@PathVariable("fromDate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate) throws DepartmentManagerNotFoundException {
		List<DepartmentManager> departmentManagers = departmentManagerService.findByDeptNoAndFromDate(deptNo, fromDate);
		System.out.println(departmentManagers);
		return departmentManagers;
	}

	//Retrieve department managers by department number and from date.
	@GetMapping("/empno/{empNo}/fromdate/{fromDate}")
	@Operation(summary = "Fetch all deptmanager objects by, id and from date")
	public DepartmentManager findByEmpNoFromDate(@PathVariable("empNo") int empNo,
			@PathVariable("fromDate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate) throws DepartmentManagerNotFoundException {
		DepartmentManager departmentManagers = departmentManagerService.findByEmpNoAndFromDate(empNo, fromDate);
		System.out.println(departmentManagers);
		return departmentManagers;
	}

	//Retrieve a department manager by employee number and from date.
	@GetMapping("/empno/{empNo}/deptno/{deptNo}/fromdate/{fromDate}")
	@Operation(summary = "Fetch all deptmanager objects by, id, deptno, and from date")
	public DepartmentManager findByEmpNoDeptNoAndFromDate(@PathVariable("empNo") int empNo,
			@PathVariable("deptNo") String deptNo,
			@PathVariable("fromDate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate) throws DepartmentManagerNotFoundException {
		return departmentManagerService.getDepartmentManagersByEmpNoAndDeptNoAndFromDate(empNo, deptNo, fromDate);
	}

	//Add a new department manager to the database.
		
	@PostMapping("/add")
    @Operation(summary = "Add new saveDepartmentManager object in DB")
    public ResponseEntity<DepartmentManager> addNewdepartmentemployee(@RequestBody DepartmentManager departmentManager) {
		DepartmentManager createdTitle = departmentManagerService.saveDepartmentManager(departmentManager);
        if (createdTitle != null) {
            return ResponseEntity.status(HttpStatus.OK).body(createdTitle);
        } else {
            throw new InvalidDataException("Validation Failed");
        }
    }
	
	//Update a department manager by department number and from date. 
	
	@Transactional
	@RequestMapping(value = "/deptNo/{deptNo}/fromdate/{fromDate}", method = { RequestMethod.PUT, RequestMethod.PATCH })
	public ResponseEntity<DepartmentManager> updateDepartmentManager(
	    @PathVariable String deptNo,
	    @PathVariable @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate,
	    @RequestBody DepartmentManager departmentManager) throws DepartmentManagerNotFoundException {

	    DepartmentManager existingDepartment = departmentManagerService.getDepartmentDeptNoAndFromDate(deptNo, fromDate);

	    if (existingDepartment != null) {
	        // Update the properties of the existing department manager
	        existingDepartment.getEmployee().setFirstName(departmentManager.getEmployee().getFirstName());
	        existingDepartment.getEmployee().setLastName(departmentManager.getEmployee().getLastName());
	        existingDepartment.getEmployee().setBirthDate(departmentManager.getEmployee().getBirthDate());

	        DepartmentManager updatedManager = departmentManagerService.updateByDeptNoAndFromDate(existingDepartment);

	        return ResponseEntity.ok(updatedManager);
	    } else {
	        return ResponseEntity.notFound().build();
	    }
	}

	
	/*
	 * Update a department manager by employee number and department number.
	 If the department manager exists, updates the manager and returns the updated DepartmentManager object with HTTP status 200 (OK).
	 *If the department manager doesn't exist, returns HTTP status 404 (Not Found).
	 */
	@Transactional
	@PutMapping("empNo/{empNo}/deptNo/{deptNo}")
	public ResponseEntity<DepartmentManager> updateDepartmentManager2(@PathVariable int empNo,
			@PathVariable String deptNo, @RequestBody DepartmentManager departmentManager) throws DepartmentManagerNotFoundException {
		
		DepartmentManager existingDepartment = departmentManagerService.getDepartmentManagerByEmpNoAndDeptNo(empNo,
				deptNo);
		if (existingDepartment != null) {
			existingDepartment.getEmployee().setFirstName(departmentManager.getEmployee().getFirstName());
			existingDepartment.getEmployee().setLastName(departmentManager.getEmployee().getLastName());
			existingDepartment.getEmployee().setBirthDate(departmentManager.getEmployee().getBirthDate());
			DepartmentManager updatedManager = departmentManagerService
					.updatebyempnoAnddeptnoAndfromdate(existingDepartment);

			return ResponseEntity.ok(updatedManager);
		} else {
			return ResponseEntity.notFound().build();
		}
	}
	
	/*
	 *Update a department manager by employee number, department number, and from date. 
	 *If the department manager exists, updates the manager and returns the updated DepartmentManager object with HTTP status 200 (OK).
	 *If the department manager doesn't exist, returns HTTP status 404 (Not Found).
	 */
	@Transactional
	@PutMapping("empNo/{empNo}/dept{deptNo}/fromdate/{fromDate}")
	public ResponseEntity<DepartmentManager> updateDepartmentManager(@PathVariable int empNo,
			@PathVariable("fromDate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate,
			@PathVariable String deptNo,
			@RequestBody DepartmentManager departmentManager) throws DepartmentManagerNotFoundException {
		DepartmentManagerId de=new DepartmentManagerId();
		DepartmentManager existingDepartment = departmentManagerService.getDepartmentManagerByEmpNoAndDeptNoAndFromDate(empNo,
				deptNo,fromDate);
		if (existingDepartment != null) {
			existingDepartment.getEmployee().setFirstName(departmentManager.getEmployee().getFirstName());
			existingDepartment.getEmployee().setLastName(departmentManager.getEmployee().getLastName());
			existingDepartment.getEmployee().setBirthDate(departmentManager.getEmployee().getBirthDate());
			existingDepartment.getEmployee().setGender(departmentManager.getEmployee().getGender());
			existingDepartment.setFromDate(departmentManager.getFromDate());
			existingDepartment.setToDate(departmentManager.getToDate());
			
			DepartmentManager updatedManager = departmentManagerService
					.updatebyempnoAnddeptnoAndfromdate(existingDepartment);

			return ResponseEntity.ok(updatedManager);
		} else {
			return ResponseEntity.notFound().build();
		}
	}
	
	/*
	 * Update a department manager by employee number and from date.
	 * If the department manager exists, updates the manager and returns the updated DepartmentManager object with HTTP status 200 (OK).
	 *If the department manager doesn't exist, returns HTTP status 404 (Not Found).
	 */
	@Transactional
	@PutMapping("empNo/{empNo}/fromdate/{fromDate}")
	public ResponseEntity<DepartmentManager> updateDepartmentManager(@PathVariable int empNo,
			@PathVariable("fromDate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate,
			
			@RequestBody DepartmentManager departmentManager) throws DepartmentManagerNotFoundException {
		DepartmentManager existingDepartment = departmentManagerService.getDepartmentManagerByEmpNoAndFromDate(empNo,
				fromDate);
		if (existingDepartment != null) {
			existingDepartment.getEmployee().setFirstName(departmentManager.getEmployee().getFirstName());
			existingDepartment.getEmployee().setLastName(departmentManager.getEmployee().getLastName());
			existingDepartment.getEmployee().setBirthDate(departmentManager.getEmployee().getBirthDate());
			existingDepartment.getEmployee().setGender(departmentManager.getEmployee().getGender());
			DepartmentManager updatedManager = departmentManagerService
					.updatebyempnoAnddeptnoAndfromdate(existingDepartment);

			return ResponseEntity.ok(updatedManager);
		} else {
			return ResponseEntity.notFound().build();
		}
	}

	/*
	 * Delete a department manager by employee number, department number, and from date.
	 *  Returns HTTP status 204 (No Content) if the deletion is successful.
	 */
	@DeleteMapping("/empno/{empNo}/deptno/{deptNo}/fromdate/{fromDate}")
	public ResponseEntity<Void> deleteDepartmentManagerByEmpNoAndDeptNoAndFromDate(@PathVariable int empNo,
			@PathVariable String deptNo, @PathVariable @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate) throws DepartmentManagerNotFoundException {
		
		departmentManagerService.deleteByEmpNoAndDeptNoAndFromDate(empNo, fromDate, deptNo);
		return ResponseEntity.noContent().build();
	}

	/*
	 *Delete a department manager by employee number and department number.
	 * Returns HTTP status 204 (No Content) if the deletion is successful.
	 */
	@DeleteMapping("/empno/{empNo}/deptno/{deptNo}")
	public ResponseEntity<Void> deleteDepartmentManagerByEmpNoAndDeptNo(@PathVariable int empNo,
			@PathVariable String deptNo) throws DepartmentManagerNotFoundException {

		departmentManagerService.deleteByEmpNoAndDeptNo(empNo, deptNo);
		return ResponseEntity.noContent().build();
	}

	/*
	 * Delete a department manager by employee number and from date.
	 * Returns HTTP status 204 (No Content) if the deletion is successful.
	 */
	@DeleteMapping("/empno/{empNo}/fromdate/{fromDate}")
	public ResponseEntity<Void> deleteDepartmentManagerByEmpNoAndFromDate(@PathVariable int empNo,
			@PathVariable @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate) throws DepartmentManagerNotFoundException {
	
		departmentManagerService.deleteByEmpNoAndFromDate(empNo, fromDate);
		return ResponseEntity.noContent().build();
	}

	/*
	 * Delete department managers by department number and from date.
	 * Returns HTTP status 204 (No Content) if the deletion is successful.
	 */
	@DeleteMapping("/deptno/{deptNo}/fromdate/{fromDate}")
	public ResponseEntity<Void> deleteDepartmentManagerByDeptNoAndFromDate(@PathVariable String deptNo,
			@PathVariable @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate)throws DepartmentManagerNotFoundException {
	
		departmentManagerService.deleteByDeptNoAndFromDate(deptNo, fromDate);
		return ResponseEntity.noContent().build();
	}

}
