/*
 * package com.cg.training.services; import static
 * org.junit.jupiter.api.Assertions.*; import static org.mockito.Mockito.*;
 * 
 * import java.time.LocalDate; import java.util.ArrayList; import
 * java.util.List;
 * 
 * import org.junit.jupiter.api.BeforeEach; import org.junit.jupiter.api.Test;
 * import org.mockito.InjectMocks; import org.mockito.Mock; import
 * org.mockito.MockitoAnnotations; import
 * org.springframework.boot.test.context.SpringBootTest;
 * 
 * import com.cg.training.entities.Titles; import
 * com.cg.training.exceptions.TitlesNotFoundException;
 * 
 * @SpringBootTest public class TitleServiceTest {
 * 
 * @Mock private TitleService titleService;
 * 
 * @BeforeEach public void setup() { MockitoAnnotations.initMocks(this); }
 * 
 * // Helper method to create Titles objects with provided data private Titles
 * createTitles(int empNo, String title, LocalDate fromDate, LocalDate toDate) {
 * Titles titles = new Titles(); titles.setEmpNo(empNo); titles.setTitle(title);
 * titles.setFromDate(fromDate); titles.setToDate(toDate); return titles; }
 * 
 * @Test public void testGetTitles() { // Create a list of Titles objects with
 * the provided data List<Titles> titlesList = new ArrayList<>();
 * titlesList.add(createTitles(10020, "Engineer", LocalDate.parse("1997-12-30"),
 * LocalDate.parse("9999-01-01"))); titlesList.add(createTitles(10021,
 * "Technique Leader", LocalDate.parse("1988-02-10"),
 * LocalDate.parse("2002-07-15"))); titlesList.add(createTitles(10022,
 * "Engineer", LocalDate.parse("1999-09-03"), LocalDate.parse("9999-01-01")));
 * titlesList.add(createTitles(10023, "Engineer", LocalDate.parse("1999-09-27"),
 * LocalDate.parse("9999-01-01"))); titlesList.add(createTitles(10024,
 * "Assistant Engineer", LocalDate.parse("1998-06-14"),
 * LocalDate.parse("9999-01-01"))); titlesList.add(createTitles(10025,
 * "Technique Leader", LocalDate.parse("1987-08-17"),
 * LocalDate.parse("1997-10-15"))); titlesList.add(createTitles(10026,
 * "Engineer", LocalDate.parse("1995-03-20"), LocalDate.parse("2001-03-19")));
 * titlesList.add(createTitles(10026, "Senior Engineer",
 * LocalDate.parse("2001-03-19"), LocalDate.parse("9999-01-01")));
 * titlesList.add(createTitles(10027, "Engineer", LocalDate.parse("1995-04-02"),
 * LocalDate.parse("2001-04-01"))); titlesList.add(createTitles(10027,
 * "Senior Engineer", LocalDate.parse("2001-04-01"),
 * LocalDate.parse("9999-01-01"))); titlesList.add(createTitles(10028,
 * "Engineer", LocalDate.parse("1991-10-22"), LocalDate.parse("1998-04-06")));
 * titlesList.add(createTitles(10029, "Engineer", LocalDate.parse("1991-09-18"),
 * LocalDate.parse("2000-09-17"))); titlesList.add(createTitles(10029,
 * "Senior Engineer", LocalDate.parse("2000-09-17"),
 * LocalDate.parse("9999-01-01"))); titlesList.add(createTitles(10030,
 * "Engineer", LocalDate.parse("1994-02-17"), LocalDate.parse("2001-02-17")));
 * titlesList.add(createTitles(10030, "Senior Engineer",
 * LocalDate.parse("2001-02-17"), LocalDate.parse("9999-01-01")));
 * titlesList.add(createTitles(10031, "Engineer", LocalDate.parse("1991-09-01"),
 * LocalDate.parse("1998-09-01"))); titlesList.add(createTitles(10031,
 * "Senior Engineer", LocalDate.parse("1998-09-01"),
 * LocalDate.parse("9999-01-01"))); titlesList.add(createTitles(10032,
 * "Engineer", LocalDate.parse("1990-06-20"), LocalDate.parse("1995-06-20")));
 * titlesList.add(createTitles(10032, "Senior Engineer",
 * LocalDate.parse("1995-06-20"), LocalDate.parse("9999-01-01")));
 * titlesList.add(createTitles(10033, "Technique Leader",
 * LocalDate.parse("1987-03-18"), LocalDate.parse("1993-03-24")));
 * titlesList.add(createTitles(10034, "Staff", LocalDate.parse("1995-04-12"),
 * LocalDate.parse("1999-10-31")));
 * 
 * // Mock the behavior of titleService.getTitles() to return the list
 * when(titleService.getTitles()).thenReturn(titlesList);
 * 
 * List<Titles> result = titleService.getTitles();
 * 
 * assertEquals(titlesList, result); }
 * 
 * @Test public void testAddTitle() { Titles titleToAdd = createTitles(10035,
 * "Engineer", LocalDate.parse("2000-01-01"), LocalDate.parse("9999-01-01"));
 * 
 * when(titleService.addTitle(titleToAdd)).thenReturn(titleToAdd);
 * 
 * Titles result = titleService.addTitle(titleToAdd);
 * 
 * assertEquals(titleToAdd, result); }
 * 
 * @Test public void testGetTitleByEmpNoAndDeptNo() throws
 * TitlesNotFoundException { int empNo = 10021; LocalDate fromDate =
 * LocalDate.parse("1995-01-01"); String title = "Technique Leader";
 * 
 * // Create a list of Titles objects with the provided data List<Titles>
 * titlesList = new ArrayList<>(); titlesList.add(createTitles(10021,
 * "Technique Leader", LocalDate.parse("1988-02-10"),
 * LocalDate.parse("2002-07-15")));
 * 
 * when(titleService.getTitleByEmpNoAndDeptNo(empNo, fromDate,
 * title)).thenReturn(titlesList);
 * 
 * List<Titles> result = titleService.getTitleByEmpNoAndDeptNo(empNo, fromDate,
 * title);
 * 
 * assertEquals(titlesList, result); }
 * 
 * @Test public void testGetTitleByEmpNoAndDeptNo_NotFound() throws
 * TitlesNotFoundException { int empNo = 10034; LocalDate fromDate =
 * LocalDate.parse("2000-01-01"); String title = "Staff";
 * 
 * when(titleService.getTitleByEmpNoAndDeptNo(empNo, fromDate,
 * title)).thenThrow(TitlesNotFoundException.class);
 * 
 * assertThrows(TitlesNotFoundException.class, () ->
 * titleService.getTitleByEmpNoAndDeptNo(empNo, fromDate, title)); }
 * 
 * @Test public void testGetAllByTitle() throws TitlesNotFoundException { String
 * title = "Engineer";
 * 
 * // Create a list of Titles objects with the provided data List<Titles>
 * titlesList = new ArrayList<>(); titlesList.add(createTitles(10020,
 * "Engineer", LocalDate.parse("1997-12-30"), LocalDate.parse("9999-01-01")));
 * titlesList.add(createTitles(10022, "Engineer", LocalDate.parse("1999-09-03"),
 * LocalDate.parse("9999-01-01"))); titlesList.add(createTitles(10023,
 * "Engineer", LocalDate.parse("1999-09-27"), LocalDate.parse("9999-01-01")));
 * titlesList.add(createTitles(10026, "Engineer", LocalDate.parse("1995-03-20"),
 * LocalDate.parse("2001-03-19"))); titlesList.add(createTitles(10027,
 * "Engineer", LocalDate.parse("1995-04-02"), LocalDate.parse("2001-04-01")));
 * titlesList.add(createTitles(10028, "Engineer", LocalDate.parse("1991-10-22"),
 * LocalDate.parse("1998-04-06"))); titlesList.add(createTitles(10029,
 * "Engineer", LocalDate.parse("1991-09-18"), LocalDate.parse("2000-09-17")));
 * titlesList.add(createTitles(10030, "Engineer", LocalDate.parse("1994-02-17"),
 * LocalDate.parse("2001-02-17"))); titlesList.add(createTitles(10031,
 * "Engineer", LocalDate.parse("1991-09-01"), LocalDate.parse("1998-09-01")));
 * titlesList.add(createTitles(10032, "Engineer", LocalDate.parse("1990-06-20"),
 * LocalDate.parse("1995-06-20")));
 * 
 * when(titleService.getAllByTitle(title)).thenReturn(titlesList);
 * 
 * List<Titles> result = titleService.getAllByTitle(title);
 * 
 * assertEquals(titlesList, result); }
 * 
 * @Test public void testGetAllByTitle_NotFound() throws TitlesNotFoundException
 * { String title = "Doctor";
 * 
 * when(titleService.getAllByTitle(title)).thenThrow(TitlesNotFoundException.
 * class);
 * 
 * assertThrows(TitlesNotFoundException.class, () ->
 * titleService.getAllByTitle(title)); }
 * 
 * @Test public void testFindAllByFromDate() throws TitlesNotFoundException {
 * LocalDate fromDate = LocalDate.parse("1995-01-01");
 * 
 * // Create a list of Titles objects with the provided data List<Titles>
 * titlesList = new ArrayList<>(); titlesList.add(createTitles(10021,
 * "Technique Leader", LocalDate.parse("1988-02-10"),
 * LocalDate.parse("2002-07-15"))); titlesList.add(createTitles(10026,
 * "Engineer", LocalDate.parse("1995-03-20"), LocalDate.parse("2001-03-19")));
 * titlesList.add(createTitles(10027, "Engineer", LocalDate.parse("1995-04-02"),
 * LocalDate.parse("2001-04-01"))); titlesList.add(createTitles(10032,
 * "Engineer", LocalDate.parse("1990-06-20"), LocalDate.parse("1995-06-20")));
 * 
 * when(titleService.findAllByFromDate(fromDate)).thenReturn(titlesList);
 * 
 * List<Titles> result = titleService.findAllByFromDate(fromDate);
 * 
 * assertEquals(titlesList, result); }
 * 
 * @Test public void testFindAllByFromDate_NotFound() throws
 * TitlesNotFoundException { LocalDate fromDate = LocalDate.parse("2025-01-01");
 * 
 * when(titleService.findAllByFromDate(fromDate)).thenThrow(
 * TitlesNotFoundException.class);
 * 
 * assertThrows(TitlesNotFoundException.class, () ->
 * titleService.findAllByFromDate(fromDate)); }
 * 
 * @Test public void testGetTitleByTitleAndFromDate() throws
 * TitlesNotFoundException { String title = "Engineer"; LocalDate fromDate =
 * LocalDate.parse("1995-01-01");
 * 
 * // Create a list of Titles objects with the provided data List<Titles>
 * titlesList = new ArrayList<>(); titlesList.add(createTitles(10020,
 * "Engineer", LocalDate.parse("1997-12-30"), LocalDate.parse("9999-01-01")));
 * titlesList.add(createTitles(10022, "Engineer", LocalDate.parse("1999-09-03"),
 * LocalDate.parse("9999-01-01"))); titlesList.add(createTitles(10023,
 * "Engineer", LocalDate.parse("1999-09-27"), LocalDate.parse("9999-01-01")));
 * titlesList.add(createTitles(10026, "Engineer", LocalDate.parse("1995-03-20"),
 * LocalDate.parse("2001-03-19"))); titlesList.add(createTitles(10027,
 * "Engineer", LocalDate.parse("1995-04-02"), LocalDate.parse("2001-04-01")));
 * titlesList.add(createTitles(10028, "Engineer", LocalDate.parse("1991-10-22"),
 * LocalDate.parse("1998-04-06"))); titlesList.add(createTitles(10029,
 * "Engineer", LocalDate.parse("1991-09-18"), LocalDate.parse("2000-09-17")));
 * titlesList.add(createTitles(10030, "Engineer", LocalDate.parse("1994-02-17"),
 * LocalDate.parse("2001-02-17"))); titlesList.add(createTitles(10031,
 * "Engineer", LocalDate.parse("1991-09-01"), LocalDate.parse("1998-09-01")));
 * titlesList.add(createTitles(10032, "Engineer", LocalDate.parse("1990-06-20"),
 * LocalDate.parse("1995-06-20")));
 * 
 * when(titleService.getTitleByTitleAndFromDate(fromDate,
 * title)).thenReturn(titlesList);
 * 
 * List<Titles> result = titleService.getTitleByTitleAndFromDate(fromDate,
 * title);
 * 
 * assertEquals(titlesList, result); }
 * 
 * @Test public void testGetTitleByTitleAndFromDate_NotFound() throws
 * TitlesNotFoundException { String title = "Doctor"; LocalDate fromDate =
 * LocalDate.parse("1995-01-01");
 * 
 * when(titleService.getTitleByTitleAndFromDate(fromDate,
 * title)).thenThrow(TitlesNotFoundException.class);
 * 
 * assertThrows(TitlesNotFoundException.class, () ->
 * titleService.getTitleByTitleAndFromDate(fromDate, title)); }
 * 
 * @Test public void testGetTitleByTitleAndFromDate_EmpNo() throws
 * TitlesNotFoundException { int empNo = 10026; String title = "Engineer";
 * 
 * // Create a list of Titles objects with the provided data List<Titles>
 * titlesList = new ArrayList<>(); titlesList.add(createTitles(10026,
 * "Engineer", LocalDate.parse("1995-03-20"), LocalDate.parse("2001-03-19")));
 * 
 * when(titleService.getTitleByTitleAndFromDate(empNo,
 * title)).thenReturn(titlesList);
 * 
 * List<Titles> result = titleService.getTitleByTitleAndFromDate(empNo, title);
 * 
 * assertEquals(titlesList, result); }
 * 
 * @Test public void testGetTitleByTitleAndFromDate_EmpNo_NotFound() throws
 * TitlesNotFoundException { int empNo = 10034; String title = "Doctor";
 * 
 * when(titleService.getTitleByTitleAndFromDate(empNo,
 * title)).thenThrow(TitlesNotFoundException.class);
 * 
 * assertThrows(TitlesNotFoundException.class, () ->
 * titleService.getTitleByTitleAndFromDate(empNo, title)); }
 * 
 * 
 * @Test public void testFindByEmpNoAndFromDateAndTitle() throws
 * TitlesNotFoundException { int empNo = 10021; LocalDate fromDate =
 * LocalDate.parse("1988-02-10"); String title = "Technique Leader";
 * 
 * Titles expectedTitles = createTitles(10021, "Technique Leader",
 * LocalDate.parse("1988-02-10"), LocalDate.parse("2002-07-15"));
 * 
 * when(titleService.findByEmpNoAndFromDateAndTitle(empNo, fromDate,
 * title)).thenReturn(expectedTitles);
 * 
 * Titles result = titleService.findByEmpNoAndFromDateAndTitle(empNo, fromDate,
 * title);
 * 
 * assertEquals(expectedTitles, result); }
 * 
 * @Test public void testFindByEmpNoAndFromDateAndTitle_NotFound() throws
 * TitlesNotFoundException { int empNo = 10034; LocalDate fromDate =
 * LocalDate.parse("2000-01-01"); String title = "Staff";
 * 
 * when(titleService.findByEmpNoAndFromDateAndTitle(empNo, fromDate,
 * title)).thenThrow(TitlesNotFoundException.class);
 * 
 * assertThrows(TitlesNotFoundException.class, () ->
 * titleService.findByEmpNoAndFromDateAndTitle(empNo, fromDate, title)); }
 * 
 * @Test public void testGetByEmpNo() throws TitlesNotFoundException { int empNo
 * = 10021;
 * 
 * Titles expectedTitles = createTitles(10021, "Technique Leader",
 * LocalDate.parse("1988-02-10"), LocalDate.parse("2002-07-15"));
 * 
 * when(titleService.getByEmpNo(empNo)).thenReturn(expectedTitles);
 * 
 * Titles result = titleService.getByEmpNo(empNo);
 * 
 * assertEquals(expectedTitles, result); }
 * 
 * @Test public void testGetByEmpNo_NotFound() throws TitlesNotFoundException {
 * int empNo = 10034;
 * 
 * when(titleService.getByEmpNo(empNo)).thenThrow(TitlesNotFoundException.class)
 * ;
 * 
 * assertThrows(TitlesNotFoundException.class, () ->
 * titleService.getByEmpNo(empNo)); }
 * 
 * @Test public void testFindByFromDates() throws TitlesNotFoundException {
 * LocalDate fromDate = LocalDate.parse("1988-02-10");
 * 
 * Titles expectedTitles = createTitles(10021, "Technique Leader",
 * LocalDate.parse("1988-02-10"), LocalDate.parse("2002-07-15"));
 * 
 * when(titleService.findByFromDates(fromDate)).thenReturn(expectedTitles);
 * 
 * Titles result = titleService.findByFromDates(fromDate);
 * 
 * assertEquals(expectedTitles, result); }
 * 
 * @Test public void testFindByFromDates_NotFound() throws
 * TitlesNotFoundException { LocalDate fromDate = LocalDate.parse("2025-01-01");
 * 
 * when(titleService.findByFromDates(fromDate)).thenThrow(
 * TitlesNotFoundException.class);
 * 
 * assertThrows(TitlesNotFoundException.class, () ->
 * titleService.findByFromDates(fromDate)); }
 * 
 * @Test public void testGetByTitle() throws TitlesNotFoundException { String
 * title = "Engineer";
 * 
 * Titles expectedTitles = createTitles(10020, "Engineer",
 * LocalDate.parse("1997-12-30"), LocalDate.parse("9999-01-01"));
 * 
 * when(titleService.getbytitle(title)).thenReturn(expectedTitles);
 * 
 * Titles result = titleService.getbytitle(title);
 * 
 * assertEquals(expectedTitles, result); }
 * 
 * @Test public void testGetByTitle_NotFound() throws TitlesNotFoundException {
 * String title = "Doctor";
 * 
 * when(titleService.getbytitle(title)).thenThrow(TitlesNotFoundException.class)
 * ;
 * 
 * assertThrows(TitlesNotFoundException.class, () ->
 * titleService.getbytitle(title)); }
 * 
 * @Test public void testUpdateByEmpNo() throws TitlesNotFoundException { Titles
 * titleToUpdate = createTitles(10021, "Technique Leader",
 * LocalDate.parse("1988-02-10"), LocalDate.parse("2002-07-15"));
 * 
 * when(titleService.updateByEmpNo(titleToUpdate)).thenReturn(titleToUpdate);
 * 
 * Titles result = titleService.updateByEmpNo(titleToUpdate);
 * 
 * assertEquals(titleToUpdate, result); }
 * 
 * @Test public void testDeleteByEmpNoFromDateAndTitle() { int empNo = 10021;
 * LocalDate fromDate = LocalDate.parse("1988-02-10"); String title =
 * "Technique Leader";
 * 
 * assertDoesNotThrow(() -> titleService.deleteByEmpNoFromDateAndTitle(empNo,
 * fromDate, title)); }
 * 
 * @Test public void testDeleteByEmpNo() { int empNo = 10021;
 * 
 * assertDoesNotThrow(() -> titleService.deleteByEmpNo(empNo)); }
 * 
 * @Test public void testDeleteByFromDate() { LocalDate fromDate =
 * LocalDate.parse("1988-02-10");
 * 
 * assertDoesNotThrow(() -> titleService.deleteByFromDate(fromDate)); }
 * 
 * @Test public void testDeleteByTitle() { String title = "Engineer";
 * 
 * assertDoesNotThrow(() -> titleService.deleteByTitle(title)); } }
 */