/*
 * package com.cg.training.controller; import static org.mockito.Mockito.*;
 * import java.util.ArrayList; import java.util.List; import
 * org.junit.jupiter.api.BeforeEach; import org.junit.jupiter.api.Test; import
 * org.mockito.InjectMocks; import org.mockito.Mock; import
 * org.mockito.MockitoAnnotations; import org.springframework.http.HttpStatus;
 * import org.springframework.http.ResponseEntity; import java.time.LocalDate;
 * import com.cg.training.controller.EmployeeController; import
 * com.cg.training.entities.Employee; import com.cg.training.entities.Gender;
 * import com.cg.training.exceptions.EmployeeNotFoundException; import
 * com.cg.training.exceptions.InvalidDataException; import
 * com.cg.training.exceptions.NotFoundException; import
 * com.cg.training.services.EmployeeServiceImpl; import static
 * org.junit.jupiter.api.Assertions.*;
 * 
 * public class EmployeeControllerTest {
 * 
 * @Mock private EmployeeServiceImpl employeeService;
 * 
 * @InjectMocks private EmployeeController employeeController;
 * 
 * @BeforeEach public void setup() { MockitoAnnotations.initMocks(this); }
 * 
 * @Test public void testFindAllEmployees() { List<Employee> employeesList = new
 * ArrayList<>(); // Add employees to the list as needed
 * 
 * when(employeeService.getEmployee()).thenReturn(employeesList);
 * 
 * List<Employee> result = employeeController.findAllEmployees();
 * 
 * assertEquals(employeesList, result); }
 * 
 * @Test public void testFindEmployeeById() throws EmployeeNotFoundException {
 * int empId = 10001; Employee employee = new Employee(10001,
 * LocalDate.parse("1953-09-02"), "Georgi", "Facello", Gender.M,
 * LocalDate.parse("1986-06-26"));
 * 
 * when(employeeService.getEmployeeById(empId)).thenReturn(employee);
 * 
 * Employee result = employeeController.findEmployeeById(empId);
 * 
 * assertEquals(employee, result); }
 * 
 * @Test public void testFindEmployeeByFirstName() throws
 * EmployeeNotFoundException { String firstName = "Georgi"; List<Employee>
 * employeesList = new ArrayList<>(); // Add employees to the list as needed
 * Employee employee = new Employee(10001, LocalDate.parse("1953-09-02"),
 * "Georgi", "Facello", Gender.M, LocalDate.parse("1986-06-26"));
 * employeesList.add(employee);
 * 
 * when(employeeService.getEmployeeByFirstName(firstName)).thenReturn(
 * employeesList);
 * 
 * List<Employee> result =
 * employeeController.findEmployeeByFirstName(firstName);
 * 
 * assertEquals(employeesList, result); }
 * 
 * @Test public void testAddEmployeeC() throws EmployeeNotFoundException {
 * Employee employee = new Employee(10002, LocalDate.parse("1964-06-02"),
 * "Bezalel", "Simmel", Gender.F, LocalDate.parse("1985-11-21")); // Create an
 * employee as needed
 * 
 * when(employeeService.addEmployee(employee)).thenReturn(employee);
 * 
 * ResponseEntity<String> response = employeeController.addEmployeeC(employee);
 * 
 * assertEquals(HttpStatus.OK, response.getStatusCode());
 * assertEquals("New employee added successfully", response.getBody()); }
 * 
 * @Test public void testUpdateEmployeeByLastNameC() throws
 * EmployeeNotFoundException { int empNo = 10001; Employee employee = new
 * Employee(10001, LocalDate.parse("1953-09-02"), "UpdatedLastName", "Facello",
 * Gender.M, LocalDate.parse("1986-06-26"));
 * 
 * when(employeeService.updateEmployeeLastName(employee,
 * empNo)).thenReturn(employee);
 * 
 * ResponseEntity<Employee> response =
 * employeeController.updateEmployeeByLastNameC(empNo, employee);
 * 
 * assertEquals(HttpStatus.OK, response.getStatusCode()); assertEquals(employee,
 * response.getBody()); }
 * 
 * @Test public void testUpdateEmployeeByFirstNameC() throws
 * EmployeeNotFoundException { int empNo = 10001; Employee employee = new
 * Employee(10001, LocalDate.parse("1953-09-02"), "UpdatedFirstName", "Facello",
 * Gender.M, LocalDate.parse("1986-06-26"));
 * 
 * when(employeeService.updateEmployeeFirstName(employee,
 * empNo)).thenReturn(employee);
 * 
 * ResponseEntity<Employee> response =
 * employeeController.updateEmployeeByFirstNameC(empNo, employee);
 * 
 * assertEquals(HttpStatus.OK, response.getStatusCode()); assertEquals(employee,
 * response.getBody()); }
 * 
 * @Test public void testUpdateEmployeeByHireDateC() throws
 * EmployeeNotFoundException { int empNo = 10001; Employee employee = new
 * Employee(10001, LocalDate.parse("1953-09-02"), "Georgi", "Facello", Gender.M,
 * LocalDate.parse("1990-01-01"));
 * 
 * when(employeeService.updateEmployeeByHireDate(employee,
 * empNo)).thenReturn(employee);
 * 
 * Employee response = employeeController.updateEmployeeByHireDateC(empNo,
 * employee);
 * 
 * assertEquals(employee, response); }
 * 
 * @Test public void testUpdateEmployeeByBirthDateC() throws
 * EmployeeNotFoundException { int empNo = 10001; Employee employee = new
 * Employee(10001, LocalDate.parse("1953-09-02"), "Georgi", "Facello", Gender.M,
 * LocalDate.parse("1953-09-03"));
 * 
 * when(employeeService.updateEmployeeBirthDate(employee,
 * empNo)).thenReturn(employee);
 * 
 * Employee response = employeeController.updateEmployeeByBirthDateC(empNo,
 * employee);
 * 
 * assertEquals(employee, response); }
 * 
 * // Write similar tests for other controller methods...
 * 
 * @Test public void testFindAllEmployeesNotFoundException() { int empId =
 * 10002; when(employeeService.getEmployeeById(empId)).thenReturn(null);
 * 
 * assertThrows(NotFoundException.class, () -> {
 * employeeController.findEmployeeById(empId); }); }
 * 
 * // Write similar tests for other exceptions and methods...
 * 
 * }
 * 
 */