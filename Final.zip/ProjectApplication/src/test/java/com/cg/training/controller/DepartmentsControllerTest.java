/*
 * package com.cg.training.controller; import static org.mockito.Mockito.*;
 * import java.util.ArrayList; import java.util.List; import
 * org.junit.jupiter.api.BeforeEach; import org.junit.jupiter.api.Test; import
 * org.mockito.InjectMocks; import org.mockito.Mock; import
 * org.mockito.MockitoAnnotations; import org.springframework.http.HttpStatus;
 * import org.springframework.http.ResponseEntity; import
 * com.cg.training.entities.Departments; import
 * com.cg.training.exceptions.DepartmentsNotFoundException; import
 * com.cg.training.exceptions.InvalidDataException; import
 * com.cg.training.services.DepartmentServiceImpl; import static
 * org.junit.jupiter.api.Assertions.*;
 * 
 * public class DepartmentsControllerTest {
 * 
 * @Mock private DepartmentServiceImpl departmentServices;
 * 
 * @InjectMocks private DepartmentsController departmentsController;
 * 
 * @BeforeEach public void setup() { MockitoAnnotations.initMocks(this); }
 * 
 * @Test public void testFindAllDepartments() { List<Departments>
 * departmentsList = new ArrayList<>(); // Add departments to the list as needed
 * 
 * when(departmentServices.getDepartments()).thenReturn(departmentsList);
 * 
 * List<Departments> result = departmentsController.findAlldepartments();
 * 
 * assertEquals(departmentsList, result); }
 * 
 * @Test public void testFindAllDepartmentsBydeptNo() throws
 * DepartmentsNotFoundException { String deptNo = "d001"; Departments department
 * = new Departments("d001", "Marketing"); // Create a department as needed
 * 
 * when(departmentServices.getDepartmentsByDepNo(deptNo)).thenReturn(department)
 * ;
 * 
 * Departments result =
 * departmentsController.findAllDepartmentsBydeptNo(deptNo);
 * 
 * assertEquals(department, result); }
 * 
 * @Test public void testFindAllDepartmentsByDeptName() throws
 * DepartmentsNotFoundException { String deptName = "Marketing";
 * List<Departments> departmentsList = new ArrayList<>(); // Add departments to
 * the list as needed Departments department = new Departments("d001",
 * "Marketing"); departmentsList.add(department);
 * 
 * when(departmentServices.getDepartmentsByDeptName(deptName)).thenReturn(
 * departmentsList);
 * 
 * List<Departments> result =
 * departmentsController.findAllDepartmentsByDeptName(deptName);
 * 
 * assertEquals(departmentsList, result); }
 * 
 * @Test public void testAddDepartmentManager() { Departments department = new
 * Departments("d010", "Test Department"); // Create a department as needed
 * 
 * when(departmentServices.addDepartment(department)).thenReturn(department);
 * 
 * ResponseEntity<String> response =
 * departmentsController.addDepartmentManager(department);
 * 
 * assertEquals(HttpStatus.OK, response.getStatusCode());
 * assertEquals("New department added successfully", response.getBody()); }
 * 
 * @Test public void testUpdateDepartmentByDeptNo() throws
 * DepartmentsNotFoundException { String deptNo = "d001"; Departments department
 * = new Departments("d001", "Updated Marketing"); // Create a department as
 * needed
 * 
 * when(departmentServices.updateByDeptNo(department)).thenReturn(department);
 * 
 * ResponseEntity<String> response =
 * departmentsController.updateDepartmentByDeptNo(deptNo, department);
 * 
 * assertEquals(HttpStatus.OK, response.getStatusCode());
 * assertEquals("Department updated successfully", response.getBody()); }
 * 
 * @Test public void testDeleteDepartmentByDeptNo() throws
 * DepartmentsNotFoundException { String deptNo = "d001";
 * doNothing().when(departmentServices).deleteByDeptNo(deptNo);
 * 
 * ResponseEntity<Void> response =
 * departmentsController.deleteDepartmentByDeptNo(deptNo);
 * 
 * assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode()); }
 * 
 * @Test public void testDeleteDepartmentByDeptName() throws
 * DepartmentsNotFoundException { String deptName = "Marketing";
 * doNothing().when(departmentServices).deleteByDeptName(deptName);
 * 
 * ResponseEntity<String> response =
 * departmentsController.deleteDepartmentByDeptName(deptName);
 * 
 * assertEquals(HttpStatus.OK, response.getStatusCode());
 * assertEquals("Department deleted successfully", response.getBody()); } }
 */