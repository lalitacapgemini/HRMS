/*
 * package com.cg.training.services;
 * 
 * import static org.junit.jupiter.api.Assertions.*; import static
 * org.mockito.Mockito.*;
 * 
 * import java.util.ArrayList; import java.util.List;
 * 
 * import org.junit.jupiter.api.BeforeEach; import org.junit.jupiter.api.Test;
 * import org.mockito.InjectMocks; import org.mockito.Mock; import
 * org.mockito.MockitoAnnotations; import org.slf4j.Logger;
 * 
 * import com.cg.training.dao.DepartmentsRepository; import
 * com.cg.training.entities.Departments; import
 * com.cg.training.exceptions.DepartmentsNotFoundException;
 * 
 * public class DepartmentServiceImplTest {
 * 
 * @Mock private DepartmentsRepository departmentRepository;
 * 
 * @InjectMocks private DepartmentServiceImpl departmentService;
 * 
 * @BeforeEach void setUp() { MockitoAnnotations.initMocks(this); }
 * 
 * 
 * 
 * @Test public void testGetDepartmentsByDepNo_notFound() { String deptNo =
 * "d002";
 * 
 * when(departmentRepository.findByDeptNo(deptNo)).thenReturn(null);
 * 
 * assertThrows(DepartmentsNotFoundException.class, () -> {
 * departmentService.getDepartmentsByDepNo(deptNo); }); }
 * 
 * 
 * @Test public void testGetDepartmentsByDeptName_notFound() { String deptName =
 * "HR";
 * 
 * when(departmentRepository.findByDeptName(deptName)).thenReturn(new
 * ArrayList<>());
 * 
 * assertThrows(DepartmentsNotFoundException.class, () -> {
 * departmentService.getDepartmentsByDeptName(deptName); }); }
 * 
 * 
 * @Test public void testUpdateByDeptNo_notFound() { String deptNo = "d002";
 * Departments department = new Departments(deptNo, "Updated HR");
 * 
 * // Mock the repository to return null when findByDeptNo is called
 * when(departmentRepository.findByDeptNo(deptNo)).thenReturn(null);
 * 
 * // Ensure that the service method throws the expected exception
 * assertThrows(DepartmentsNotFoundException.class, () -> {
 * departmentService.updateByDeptNo(department); }); }
 * 
 * @Test public void testDeleteByDeptNo_success() { String deptNo = "d001";
 * 
 * // Mock the repository to return a department when findByDeptNo is called
 * when(departmentRepository.findByDeptNo(deptNo)).thenReturn(new
 * Departments(deptNo, "Marketing"));
 * 
 * // Call the delete method departmentService.deleteByDeptNo(deptNo);
 * 
 * // Verify that the repository's delete method was called once
 * verify(departmentRepository, times(1)).delete(any(Departments.class)); }
 * 
 * 
 * 
 * @Test public void testDeleteByDeptNo_notFound() { String deptNo = "d002";
 * 
 * when(departmentRepository.findByDeptNo(deptNo)).thenReturn(null);
 * 
 * assertThrows(DepartmentsNotFoundException.class, () -> {
 * departmentService.deleteByDeptNo(deptNo); });
 * 
 * verify(departmentRepository, never()).delete(any(Departments.class)); }
 * 
 * @Test public void testDeleteByDeptName_success() throws
 * DepartmentsNotFoundException { String deptName = "Marketing";
 * 
 * // Mock the repository to return a deleteCount (e.g., "1") when
 * deleteByDeptName is called
 * when(departmentRepository.deleteByDeptName(deptName)).thenReturn("1");
 * 
 * // Call the delete method departmentService.deleteByDeptName(deptName);
 * 
 * // Verify that the repository's deleteByDeptName method was called once
 * verify(departmentRepository, times(1)).deleteByDeptName(deptName); }
 * 
 * @Test public void testDeleteByDeptName_notFound() { String deptName = "HR";
 * 
 * // Mock the repository to return null when deleteByDeptName is called
 * when(departmentRepository.deleteByDeptName(deptName)).thenReturn(null);
 * 
 * // Ensure that the service method throws the expected exception
 * assertThrows(DepartmentsNotFoundException.class, () -> {
 * departmentService.deleteByDeptName(deptName); });
 * 
 * // Verify that the repository's deleteByDeptName method was called once
 * verify(departmentRepository, times(1)).deleteByDeptName(deptName); } // Add
 * more test cases for other methods as needed
 * 
 * }
 */