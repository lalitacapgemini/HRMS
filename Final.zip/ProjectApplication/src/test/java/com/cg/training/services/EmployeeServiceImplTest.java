/*
 * package com.cg.training.services;
 * 
 * import com.cg.training.dao.EmployeeRepository; import
 * com.cg.training.entities.Employee; import com.cg.training.entities.Gender;
 * import com.cg.training.exceptions.EmployeeNotFoundException; import
 * org.junit.jupiter.api.BeforeEach; import org.junit.jupiter.api.Test; import
 * org.mockito.InjectMocks; import org.mockito.Mock; import
 * org.mockito.MockitoAnnotations; import java.time.LocalDate; import
 * java.util.ArrayList; import java.util.List; import static
 * org.junit.jupiter.api.Assertions.assertEquals; import static
 * org.mockito.Mockito.*;
 * 
 * public class EmployeeServiceImplTest {
 * 
 * @Mock private EmployeeRepository employeeRepository; // Replace with your
 * actual repository class
 * 
 * @InjectMocks private EmployeeServiceImpl employeeService; // Replace with
 * your actual service class
 * 
 * @BeforeEach public void setup() { // Initialize mockito annotations
 * MockitoAnnotations.initMocks(this); }
 * 
 * @Test public void testGetEmployee() { // Arrange List<Employee> employees =
 * new ArrayList<>(); employees.add(new Employee(10001,
 * LocalDate.parse("1953-09-02"), "Georgi", "Facello", Gender.M,
 * LocalDate.parse("1986-06-26")));
 * when(employeeRepository.findAll()).thenReturn(employees);
 * 
 * // Act List<Employee> result = employeeService.getEmployee();
 * 
 * // Assert assertEquals(1, result.size()); assertEquals(employees.get(0),
 * result.get(0)); }
 * 
 * @Test public void testGetEmployeeById() throws EmployeeNotFoundException { //
 * Arrange int empNo = 10001; Employee expectedEmployee = new Employee(empNo,
 * LocalDate.parse("1953-09-02"), "Georgi", "Facello", Gender.M,
 * LocalDate.parse("1986-06-26"));
 * when(employeeRepository.findById(empNo)).thenReturn(java.util.Optional.
 * ofNullable(expectedEmployee));
 * 
 * // Act Employee result = employeeService.getEmployeeById(empNo);
 * 
 * // Assert assertEquals(expectedEmployee, result); }
 * 
 * @Test public void testGetEmployeeByFirstName() throws
 * EmployeeNotFoundException { // Arrange String firstName = "Georgi";
 * List<Employee> employees = new ArrayList<>(); employees.add(new
 * Employee(10001, LocalDate.parse("1953-09-02"), firstName, "Facello",
 * Gender.M, LocalDate.parse("1986-06-26")));
 * when(employeeRepository.findByFirstNameContains(firstName)).thenReturn(
 * employees);
 * 
 * // Act List<Employee> result =
 * employeeService.getEmployeeByFirstName(firstName);
 * 
 * // Assert assertEquals(1, result.size()); assertEquals(firstName,
 * result.get(0).getFirstName()); }
 * 
 * @Test public void testGetEmployeeByLastName() throws
 * EmployeeNotFoundException { // Arrange String lastName = "Facello";
 * List<Employee> employees = new ArrayList<>(); employees.add(new
 * Employee(10001, LocalDate.parse("1953-09-02"), "Georgi", lastName, Gender.M,
 * LocalDate.parse("1986-06-26")));
 * when(employeeRepository.findByLastNameContains(lastName)).thenReturn(
 * employees);
 * 
 * // Act List<Employee> result =
 * employeeService.getEmployeeByLastName(lastName);
 * 
 * // Assert assertEquals(1, result.size()); assertEquals(lastName,
 * result.get(0).getLastName()); }
 * 
 * @Test public void testGetEmployeesByGender() { // Arrange Gender gender =
 * Gender.M; List<Employee> employees = new ArrayList<>(); employees.add(new
 * Employee(10001, LocalDate.parse("1953-09-02"), "Georgi", "Facello", gender,
 * LocalDate.parse("1986-06-26")));
 * when(employeeRepository.findByGenderContains(gender)).thenReturn(employees);
 * 
 * // Act List<Employee> result = employeeService.getEmployeesByGender(gender);
 * 
 * // Assert assertEquals(1, result.size()); assertEquals(gender,
 * result.get(0).getGender()); }
 * 
 * @Test public void testGetEmployeesByHireDate() throws
 * EmployeeNotFoundException { // Arrange LocalDate hireDate =
 * LocalDate.parse("1986-06-26"); List<Employee> employees = new ArrayList<>();
 * employees.add(new Employee(10001, LocalDate.parse("1953-09-02"), "Georgi",
 * "Facello", Gender.M, hireDate));
 * when(employeeRepository.findByHireDate(hireDate)).thenReturn(employees);
 * 
 * // Act List<Employee> result =
 * employeeService.getEmployeesByHireDate(hireDate);
 * 
 * // Assert assertEquals(1, result.size()); assertEquals(hireDate,
 * result.get(0).getHireDate()); }
 * 
 * @Test public void testGetEmployeesByBirthDate() throws
 * EmployeeNotFoundException { // Arrange LocalDate birthDate =
 * LocalDate.parse("1953-09-02"); List<Employee> employees = new ArrayList<>();
 * employees.add(new Employee(10001, birthDate, "Georgi", "Facello", Gender.M,
 * LocalDate.parse("1986-06-26")));
 * when(employeeRepository.findByBirthDate(birthDate)).thenReturn(employees);
 * 
 * // Act List<Employee> result =
 * employeeService.getEmployeesByBirthDate(birthDate);
 * 
 * // Assert assertEquals(1, result.size()); assertEquals(birthDate,
 * result.get(0).getBirthDate()); }
 * 
 * @Test public void testAddEmployee() throws EmployeeNotFoundException { //
 * Arrange Employee newEmployee = new Employee(10002,
 * LocalDate.parse("1964-06-02"), "Bezalel", "Simmel", Gender.F,
 * LocalDate.parse("1985-11-21"));
 * when(employeeRepository.save(newEmployee)).thenReturn(newEmployee);
 * 
 * // Act Employee result = employeeService.addEmployee(newEmployee);
 * 
 * // Assert assertEquals(newEmployee, result); }
 * 
 * @Test public void testUpdateEmployeeLastName() throws
 * EmployeeNotFoundException { // Arrange int empNo = 10001; Employee
 * employeeToUpdate = new Employee(empNo, LocalDate.parse("1953-09-02"),
 * "Georgi", "NewLastName", Gender.M, LocalDate.parse("1986-06-26")); Employee
 * updatedEmployee = new Employee(empNo, LocalDate.parse("1953-09-02"),
 * "Georgi", "NewLastName", Gender.M, LocalDate.parse("1986-06-26"));
 * when(employeeRepository.findById(empNo)).thenReturn(java.util.Optional.
 * ofNullable(employeeToUpdate));
 * when(employeeRepository.save(employeeToUpdate)).thenReturn(updatedEmployee);
 * 
 * // Act Employee result =
 * employeeService.updateEmployeeLastName(employeeToUpdate, empNo);
 * 
 * // Assert assertEquals(updatedEmployee.getLastName(), result.getLastName());
 * }
 * 
 * @Test public void testUpdateEmployeeFirstName() throws
 * EmployeeNotFoundException { // Arrange int empNo = 10001; Employee
 * employeeToUpdate = new Employee(empNo, LocalDate.parse("1953-09-02"),
 * "NewFirstName", "Facello", Gender.M, LocalDate.parse("1986-06-26")); Employee
 * updatedEmployee = new Employee(empNo, LocalDate.parse("1953-09-02"),
 * "NewFirstName", "Facello", Gender.M, LocalDate.parse("1986-06-26"));
 * when(employeeRepository.findById(empNo)).thenReturn(java.util.Optional.
 * ofNullable(employeeToUpdate));
 * when(employeeRepository.save(employeeToUpdate)).thenReturn(updatedEmployee);
 * 
 * // Act Employee result =
 * employeeService.updateEmployeeFirstName(employeeToUpdate, empNo);
 * 
 * // Assert assertEquals(updatedEmployee.getFirstName(),
 * result.getFirstName()); }
 * 
 * @Test public void testUpdateEmployeeByHireDate() throws
 * EmployeeNotFoundException { // Arrange int empNo = 10001; LocalDate
 * newHireDate = LocalDate.parse("1990-01-01"); Employee employeeToUpdate = new
 * Employee(empNo, LocalDate.parse("1953-09-02"), "Georgi", "Facello", Gender.M,
 * LocalDate.parse("1986-06-26")); Employee updatedEmployee = new
 * Employee(empNo, LocalDate.parse("1953-09-02"), "Georgi", "Facello", Gender.M,
 * newHireDate);
 * when(employeeRepository.findById(empNo)).thenReturn(java.util.Optional.
 * ofNullable(employeeToUpdate));
 * when(employeeRepository.save(employeeToUpdate)).thenReturn(updatedEmployee);
 * 
 * // Act Employee result =
 * employeeService.updateEmployeeByHireDate(employeeToUpdate, empNo);
 * 
 * // Assert assertEquals(updatedEmployee.getHireDate(), result.getHireDate());
 * }
 * 
 * @Test public void testUpdateEmployeeBirthDate() throws
 * EmployeeNotFoundException { // Arrange int empNo = 10001; LocalDate
 * newBirthDate = LocalDate.parse("1960-01-01"); Employee employeeToUpdate = new
 * Employee(empNo, LocalDate.parse("1953-09-02"), "Georgi", "Facello", Gender.M,
 * LocalDate.parse("1986-06-26")); Employee updatedEmployee = new
 * Employee(empNo, newBirthDate, "Georgi", "Facello", Gender.M,
 * LocalDate.parse("1986-06-26"));
 * when(employeeRepository.findById(empNo)).thenReturn(java.util.Optional.
 * ofNullable(employeeToUpdate));
 * when(employeeRepository.save(employeeToUpdate)).thenReturn(updatedEmployee);
 * 
 * // Act Employee result =
 * employeeService.updateEmployeeBirthDate(employeeToUpdate, empNo);
 * 
 * // Assert assertEquals(updatedEmployee.getBirthDate(),
 * result.getBirthDate()); } }
 * 
 */